import axios from "axios";

export function getArticles(){

    return new Promise((resolve, reject) => {
        axios
        .get("https://newsapi.org/v2/top-headlines?country=nz&apiKey=9d223797796543eb8e4ceb3fa511324b")
        .then(response => {
          // create an array of articles only with relevant data
          const newArticles = response.data.articles.map(a => {
            return {
              author: a.author,
              content: a.content==null?'':a.content,
              description: a.description,
              publishedTime: a.publishedAt,
              title: a.title,
              siteUrl: a.url,
              imgUrl: a.urlToImage,
              active:false
            };
          });
          resolve(newArticles);
          return;
        })
        .catch(error => reject(error));

    });

}

